#!/usr/bin/env python3
"""Test script for WebSocket server functionality."""

import asyncio
import json
import aiohttp
import websockets
from terminal_lyrics.sources.local_ingest import start_ingest_server_async


async def test_server():
    """Test the WebSocket server functionality."""
    print("Starting test server...")

    # Start the server
    store, runner, site = await start_ingest_server_async("127.0.0.1", 0)
    port = site._server.sockets[0].getsockname()[1]

    print(f"Server started on port {port}")
    print(f"WebSocket endpoint: ws://127.0.0.1:{port}/ws")
    print(f"HTTP endpoint: http://127.0.0.1:{port}/lyrics")

    # Test HTTP health endpoint
    print("\nTesting HTTP health endpoint...")
    async with aiohttp.ClientSession() as session:
        async with session.get(f"http://127.0.0.1:{port}/health") as response:
            result = await response.json()
            print(f"Health check result: {result}")

    # Test WebSocket connection
    print("\nTesting WebSocket connection...")
    messages_received = []

    async def websocket_client():
        try:
            uri = f"ws://127.0.0.1:{port}/ws"
            async with websockets.connect(uri) as websocket:
                print("WebSocket connected")

                # Listen for messages with timeout
                try:
                    async for message in websocket:
                        data = json.loads(message)
                        print(f"WebSocket received: {data}")
                        messages_received.append(data)

                        # Break after receiving a few messages
                        if len(messages_received) >= 2:
                            break

                except asyncio.TimeoutError:
                    print("WebSocket timeout (expected)")

        except Exception as e:
            print(f"WebSocket error: {e}")

    # Start WebSocket client
    ws_task = asyncio.create_task(websocket_client())

    # Wait for connection
    await asyncio.sleep(0.5)

    # Test HTTP POST with lyrics
    print("\nTesting HTTP POST with lyrics...")
    test_data = {
        "artist": "Test Artist",
        "title": "Test Song",
        "lyrics": "[00:00.00] This is a test\n[00:05.00] WebSocket notification test",
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(f"http://127.0.0.1:{port}/lyrics", json=test_data) as response:
            result = await response.json()
            print(f"HTTP POST result: {result}")

    # Test unbound lyrics
    print("\nTesting unbound lyrics POST...")
    unbound_data = {"lyrics": "This is unbound lyrics text for testing"}

    async with aiohttp.ClientSession() as session:
        async with session.post(f"http://127.0.0.1:{port}/lyrics", json=unbound_data) as response:
            result = await response.json()
            print(f"Unbound POST result: {result}")

    # Wait for WebSocket messages
    await asyncio.sleep(1)

    # Cancel WebSocket task
    ws_task.cancel()
    try:
        await ws_task
    except asyncio.CancelledError:
        pass

    # Stop the server
    print("\nStopping server...")
    await site.stop()
    await runner.cleanup()

    print(f"\nTest completed! Received {len(messages_received)} WebSocket messages")
    for i, msg in enumerate(messages_received, 1):
        print(f"Message {i}: {msg}")


if __name__ == "__main__":
    asyncio.run(test_server())
