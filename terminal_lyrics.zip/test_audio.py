#!/usr/bin/env python3
"""Test script for audio capture functionality."""

import logging
import time
import sys

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

from terminal_lyrics.audio.analyzer import AudioAnalyzer


def main():
    print("=== Audio Capture Test ===\n")

    # Create analyzer
    analyzer = AudioAnalyzer(num_bands=20)

    print(f"Audio available: {analyzer.is_available()}")
    print(f"Backend: {analyzer.audio_backend}")
    print(f"Monitor source: {analyzer.monitor_source_name}")
    print()

    if not analyzer.is_available():
        print("Audio capture not available!")
        print("\nTo enable audio capture:")
        print("  1. Make sure you're in a graphical session (not SSH)")
        print("  2. Install: pip install pulsectl sounddevice numpy")
        print("  3. For PulseAudio/PipeWire, ensure XDG_RUNTIME_DIR is set")
        return 1

    # Start capture
    print("Starting audio capture...")
    if not analyzer.start():
        print("Failed to start audio capture!")
        return 1

    print(f"Capture running: {analyzer.is_running()}")
    print("\nCollecting audio data for 5 seconds...")
    print("(Play some music to see the visualizer work)\n")

    try:
        for i in range(15):
            time.sleep(1)
            freq_data = analyzer.get_frequency_data()

            # Simple bar visualization
            bars = ""
            for freq in freq_data:
                bar_height = int(freq * 10)
                bars += "█" * bar_height + " "

            total = sum(freq_data)
            print(f"[{i + 1}/15] Total: {total:.3f} | {bars}")

            if total == 0:
                print("       (No audio detected - is music playing?)")

    except KeyboardInterrupt:
        print("\n\nInterrupted by user")

    finally:
        print("\nStopping capture...")
        analyzer.stop()
        print("Done!")

    return 0


if __name__ == "__main__":
    sys.exit(main())
