#!/usr/bin/env python3
"""Simple test script for WebSocket server functionality using HTTP only."""

import asyncio
import json
import aiohttp
from terminal_lyrics.sources.local_ingest import start_ingest_server_async


async def test_server():
    """Test the WebSocket server functionality."""
    print("Starting test server...")

    # Start the server
    store, runner, site = await start_ingest_server_async("127.0.0.1", 7777)
    port = 7777

    print(f"Server started on port {port}")
    print(f"WebSocket endpoint: ws://127.0.0.1:{port}/ws")
    print(f"HTTP endpoint: http://127.0.0.1:{port}/lyrics")

    # Test HTTP health endpoint
    print("\n1. Testing HTTP health endpoint...")
    async with aiohttp.ClientSession() as session:
        async with session.get(f"http://127.0.0.1:{port}/health") as response:
            result = await response.json()
            print(f"✓ Health check result: {result}")

    # Test HTTP POST with lyrics (this should trigger WebSocket notifications)
    print("\n2. Testing HTTP POST with lyrics...")
    test_data = {
        "artist": "Test Artist",
        "title": "Test Song",
        "lyrics": "[00:00.00] This is a test\n[00:05.00] WebSocket notification test",
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(f"http://127.0.0.1:{port}/lyrics", json=test_data) as response:
            result = await response.json()
            print(f"✓ HTTP POST result: {result}")

    # Test unbound lyrics
    print("\n3. Testing unbound lyrics POST...")
    unbound_data = {"lyrics": "This is unbound lyrics text for testing"}

    async with aiohttp.ClientSession() as session:
        async with session.post(f"http://127.0.0.1:{port}/lyrics", json=unbound_data) as response:
            result = await response.json()
            print(f"✓ Unbound POST result: {result}")

    # Test invalid data
    print("\n4. Testing invalid POST data...")
    async with aiohttp.ClientSession() as session:
        async with session.post(f"http://127.0.0.1:{port}/lyrics", data="invalid json") as response:
            result = await response.json()
            print(f"✓ Invalid data result: {result}")

    # Test query parameters
    print("\n5. Testing query parameter POST...")
    async with aiohttp.ClientSession() as session:
        url = f"http://127.0.0.1:{port}/lyrics?artist=QueryArtist&title=QuerySong"
        async with session.post(url, data="Query lyrics text") as response:
            result = await response.json()
            print(f"✓ Query POST result: {result}")

    # Check that WebSocket connections are tracked
    print(f"\n6. WebSocket connections tracked: {len(store._ws_connections)} active connections")

    # Stop the server
    print("\nStopping server...")
    await site.stop()
    await runner.cleanup()

    print("\n✓ All tests completed successfully!")
    print("\nTo test WebSocket connections manually:")
    print(f"1. Start server: python -m terminal_lyrics ws-test --port {port}")
    print(f"2. Connect WebSocket client to: ws://127.0.0.1:{port}/ws")
    print("3. POST lyrics to see real-time notifications")


if __name__ == "__main__":
    asyncio.run(test_server())
