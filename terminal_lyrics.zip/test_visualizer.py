#!/usr/bin/env python3
"""Test script for visualizer rendering."""

import time
import sys
from terminal_lyrics.render.visualizer import MusicVisualizer


def clear_screen():
    """Clear terminal screen."""
    print("\033[2J\033[H", end="")


def main():
    styles = ["bars", "spectrum", "equalizer", "wave", "pulse", "notes"]

    print("Testing visualizer styles...")
    print("Press Ctrl+C to exit\n")

    for style in styles:
        print(f"\n=== Style: {style} ===\n")

        visualizer = MusicVisualizer(width=30, height=5, style=style, use_real_audio=True)

        # Simulate for 3 seconds
        for _ in range(15):
            visualizer.update(is_playing=True)

            # Clear and render
            clear_screen()
            print(f"Style: {style}\n")

            lines = visualizer.render()
            for line in lines:
                print(line)

            # Show compact version
            print("\nCompact:")
            print(visualizer.render_compact())

            time.sleep(0.2)

        time.sleep(1)

    print("\n\nAll styles tested!")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
        sys.exit(0)
