#!/usr/bin/env python3
"""Simple WebSocket test client for terminal_lyrics WebSocket server."""

import asyncio
import json
import websockets
import aiohttp


async def test_websocket_client(uri):
    """Test WebSocket connection and message handling."""
    try:
        async with websockets.connect(uri) as websocket:
            print(f"Connected to {uri}")

            # Listen for messages
            async for message in websocket:
                data = json.loads(message)
                print(f"Received: {data}")

    except Exception as e:
        print(f"WebSocket error: {e}")


async def test_http_post(url, data):
    """Test HTTP POST endpoint."""
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(url, json=data) as response:
                result = await response.json()
                print(f"HTTP POST result: {result}")
                return result
        except Exception as e:
            print(f"HTTP POST error: {e}")


async def main():
    # Test data
    host = "127.0.0.1"
    port = 40095  # Update this to match the server port

    ws_uri = f"ws://{host}:{port}/ws"
    http_url = f"http://{host}:{port}/lyrics"

    print("Testing WebSocket and HTTP endpoints...")

    # Start WebSocket client in background
    ws_task = asyncio.create_task(test_websocket_client(ws_uri))

    # Wait a bit then send some test lyrics
    await asyncio.sleep(1)

    test_lyrics = {
        "artist": "Test Artist",
        "title": "Test Song",
        "lyrics": "[00:00.00] This is a test\n[00:05.00] WebSocket notification",
    }

    await test_http_post(http_url, test_lyrics)

    # Wait a bit more
    await asyncio.sleep(2)

    # Cancel WebSocket task
    ws_task.cancel()
    try:
        await ws_task
    except asyncio.CancelledError:
        pass

    print("Test completed")


if __name__ == "__main__":
    asyncio.run(main())
